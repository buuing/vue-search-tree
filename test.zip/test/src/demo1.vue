<template>
  <div id="demo1">
    <slot></slot>
    <vue-run-sfc title="基础用法" :code="code" height="300px"></vue-run-sfc>
  </div>
</template>

<script>
export default {
  data () {
    return {
      code: `<template>
  <SearchTree
    node-key="id"
    :data="treeList"
    :default-expand-all="true"
  ></SearchTree>
</template>

<script>
export default {
  data() {
    return {
      treeList: [
        {
          "id": 1000,
          "name": "河南省",
          "children": [{
            "id": 1009,
            "name": "新乡市",
            "children": [{
              "id": 1119,
              "name": "新乡市宏力大道店"
            }, {
              "id": 1120,
              "name": "新乡市胜利北街店"
            }, {
              "id": 1121,
              "name": "新乡市首比街店"
            }]
          },
          {
            "id": 1016,
            "name": "巩义市",
            "children": [{
              "id": 1254,
              "name": "巩义市新兴路店"
            }]
          }]
        }
      ],
    }
  }
}
<\/script>`
    }
  }
}
</script>

<style>
#demo1 iframe {
  min-height: 200px !important;
}
</style>
