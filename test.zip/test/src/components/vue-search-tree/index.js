require('./dist/index.css')
module.exports = require('./dist/index.common.js')
