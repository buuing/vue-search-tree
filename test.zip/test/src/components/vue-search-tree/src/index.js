import SearchTree from './search-tree'
export default {
  install (Vue, options) {
    Vue.component('SearchTree', SearchTree)
  }
}
