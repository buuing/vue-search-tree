<template>
  <div id="demo3">
    <slot></slot>
    <vue-run-sfc title="模糊搜索功能" :code="code" height="500px"></vue-run-sfc>
  </div>
</template>

<script>
export default {
  data () {
    return {
      code: `<template>
  <div>
    通过search设置关键词
    <input v-model="input" type="text" />
    <SearchTree
      node-key="id"
      :data="treeList"
      :search="input"
      :default-expand-all="true"
    ></SearchTree>
  </div>
</template>

<script>
export default {
  data() {
    return {
      input: '济南无影山',
      treeList: [
        {
          "id": 1000,
          "name": "河南省",
          "children": [{
            "id": 1009,
            "name": "新乡市",
            "children": [{
              "id": 1119,
              "name": "新乡市宏力大道店"
            }, {
              "id": 1120,
              "name": "新乡市胜利北街店"
            }, {
              "id": 1121,
              "name": "新乡市首比街店"
            }]
          },
          {
            "id": 1016,
            "name": "巩义市",
            "children": [{
              "id": 1254,
              "name": "巩义市新兴路店"
            }]
          }]
        }, {
          "id": 1001,
          "name": "河北省",
          "children": []
        }, {
          "id": 1007,
          "name": "山东省",
          "children": [{
            "id": 1103,
            "name": "济南市",
            "children": [{
              "id": 2544,
              "name": "济南市无影山西路店"
            }, {
              "id": 2545,
              "name": "济南市堤口路店"
            }]
          }, {
            "id": 1105,
            "name": "沂市",
            "children": [{
              "id": 2561,
              "name": "沂市东岳庙店"
            }]
          }]
        }, {
          "id": 1008,
          "name": "甘肃省",
          "children": [{
            "id": 1111,
            "name": "兰州市",
            "children": [{
              "id": 2649,
              "name": "兰州市金港城店"
            }, {
              "id": 2651,
              "name": "兰州市秦安路店"
            }]
          }]
        }
      ],
    }
  }
}
<\/script>`,
    }
  }
}
</script>

<style>
#demo3 iframe {
  min-height: 400px !important;
}
</style>
