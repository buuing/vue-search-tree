<template>
  <div id="demo5">
    <slot></slot>
    <vue-run-sfc title="基础用法" :code="code" height="400px"></vue-run-sfc>
  </div>
</template>

<script>
export default {
  data () {
    return {
      code: `<template>
  <SearchTree
    ref="tree"
    node-key="id"
    :data="treeList"
    :default-expand-all="true"
  >
    <template slot-scope="scope">
      <p style="margin: 5px">
        <span>{{scope.name}}</span>
        <button
          v-if="scope.level === 3"
          @click="handleRemove(scope)"
          style="float: right"
        >删除</button>
      </p>
    </template>
  </SearchTree>
</template>

<script>
export default {
  data() {
    return {
      treeList: [
        {
          "id": 1007,
          "name": "山东省",
          "children": [{
            "id": 1103,
            "name": "济南市",
            "children": [{
              "id": 2544,
              "name": "济南市无影山西路店"
            }, {
              "id": 2545,
              "name": "济南市堤口路店"
            }]
          }, {
            "id": 1105,
            "name": "沂市",
            "children": [{
              "id": 2561,
              "name": "沂市东岳庙店"
            }]
          }]
        }
      ],
    }
  },
  methods: {
    handleRemove (data) {
      this.$refs.tree.remove()
    }
  }
}
<\/script>`
    }
  }
}
</script>

<style>
#demo5 iframe {
  min-height: 400px !important;
}
</style>
