import Vue from 'vue'
import App from './App.vue'
// import SearchTree from 'vue-search-tree'
// Vue.use(SearchTree)
import SearchTree from '@/components/vue-search-tree/src/search-tree.vue'
Vue.component('SearchTree', SearchTree)

import VueRunSfc from 'vue-run-sfc'

Vue.use(VueRunSfc, {
  css: `
    .tree-ul {
      margin: 0;
      padding: 0 0 0 15px;
    }
    .tree-li {
      margin: 0;
      padding: 0;
      list-style: none;
      display: flex;
      align-items: center;
    }
    .tree-checkbox {
      margin: 0 0 0 4px;
      transform: translateY(1px);
    }
    .tree-content {
      width: 100%;
      margin: 0 0 0 3px;
    }
    .tree-content p {
      margin: 0;
    }
    .tree-text {
      margin: 0;
    }
    .point {
      cursor: pointer;
    }
    .ldq-tree {
      user-select: none;
    }
  `,
  row: true,
  reverse: true,
  height: '400px',
  open: true,
  isHideHeader: false,
  themeColor: '#6190E8'
})
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
